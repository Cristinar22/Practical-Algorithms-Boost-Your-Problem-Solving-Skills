import json, random, pathlib, string
from datetime import date, timedelta

N = 10_000
DATA = pathlib.Path("orders.json")

def rnd_word(k=8):
    return "".join(random.choice(string.ascii_lowercase) for _ in range(k))

rows = []
for _ in range(N):
    rows.append({
        "order_id": rnd_word(6),
        "amount": round(random.uniform(5, 5000), 2),
        "date": str(date.today() - timedelta(days=random.randint(0, 365)))
    })

DATA.write_text(json.dumps(rows))
print("Wrote", DATA)