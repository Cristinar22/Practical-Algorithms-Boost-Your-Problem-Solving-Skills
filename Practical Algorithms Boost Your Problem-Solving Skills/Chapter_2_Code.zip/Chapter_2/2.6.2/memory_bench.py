import tracemalloc, packet_parsers, random

def bench(fn):
    data = bytes(random.getrandbits(8) for _ in range(2_000_000))
    tracemalloc.start()
    fn(data)
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / 1024

print("chunk:", bench(packet_parsers.chunk))
print("full :", bench(packet_parsers.full))