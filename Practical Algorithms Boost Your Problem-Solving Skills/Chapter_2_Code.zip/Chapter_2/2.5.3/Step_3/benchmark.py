import json, timeit, matplotlib.pyplot as plt
from sorters import insertion_sort, merge_sort   # your module

with open("orders.json") as f:
    base = json.load(f)

funcs = {
    "built_in": lambda lst: sorted(lst, key=lambda x: x["amount"]),
    "insertion": lambda lst: insertion_sort(lst, key=lambda x: x["amount"]),
    "merge":     lambda lst: merge_sort(lst,     key=lambda x: x["amount"]),
}

results = {}
for name, fn in funcs.items():
    t = timeit.timeit(
        stmt="fn(arr.copy())",
        number=5,
        globals={"fn": fn, "arr": base}
    )
    results[name] = t / 5   # average

print(results)

plt.bar(results.keys(), results.values())
plt.ylabel("Seconds (lower is better)")
plt.title("Sorting 10 000 JSON Orders")
plt.savefig("sort_benchmark.png")