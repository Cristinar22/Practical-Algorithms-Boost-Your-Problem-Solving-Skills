def insertion_sort(arr, key):
    for i in range(1, len(arr)):
        cur, j = arr[i], i - 1
        while j >= 0 and key(arr[j]) > key(cur):
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = cur
    return arr

def merge_sort(arr, key):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid], key)
    right = merge_sort(arr[mid:], key)
    merged = []
    while left and right:
        if key(left[0]) < key(right[0]):
            merged.append(left.pop(0))
        else:
            merged.append(right.pop(0))
    merged.extend(left or right)
    return merged