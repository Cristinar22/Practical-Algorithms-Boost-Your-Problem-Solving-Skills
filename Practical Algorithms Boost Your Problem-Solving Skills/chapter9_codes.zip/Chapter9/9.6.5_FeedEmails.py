import mailbox
from MailBloom import MailBloom

mb = mailbox.mbox('inbox.mbox')
bf = MailBloom(5_000_000, 0.05)
dupes = 0

for msg in mb:
    key = msg['Message-Id'] or hash(msg.get_payload(decode=True))
    if bf.seen(key):
        dupes += 1
        # tag as duplicate
    else:
        bf.add(key)

print("Duplicates flagged:", dupes)
print("Memory used MB:", bf.bits.buffer_info()[1] / 1024 / 1024)
