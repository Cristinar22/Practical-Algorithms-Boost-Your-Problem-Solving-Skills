import math
import mmh3

class CMSketch:
    def __init__(self, eps=0.01, delta=0.01):
        self.w = int(math.e / eps)
        self.d = int(math.log(1/delta))
        self.table = [[0] * self.w for _ in range(self.d)]

    def add(self, key, count=1):
        for i, row in enumerate(self.table):
            j = mmh3.hash(key, i) % self.w
            row[j] += count

    def query(self, key):
        return min(
            self.table[i][mmh3.hash(key, i) % self.w]
            for i in range(self.d)
        )
