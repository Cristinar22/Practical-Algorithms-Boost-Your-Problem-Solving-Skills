from math import log

N = 5_000_000
FP = 0.05
m = -N * log(FP) / (log(2)**2)          # bits
k = m / N * log(2)
print("bits", int(m), "hashes", int(k))
