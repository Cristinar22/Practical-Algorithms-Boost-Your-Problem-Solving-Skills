from math import log
from bitarray import bitarray
import mmh3

class MailBloom:
    def __init__(self, items, fp):
        m = int(-items * log(fp) / (log(2)**2))
        self.k = int(round(m / items * log(2)))
        self.bits = bitarray(m)
        self.bits.setall(0)

    def _hashes(self, key):
        for i in range(self.k):
            yield mmh3.hash(key, i, signed=False) % self.bits.length()

    def add(self, key):
        for h in self._hashes(key):
            self.bits[h] = 1

    def seen(self, key):
        return all(self.bits[h] for h in self._hashes(key))
