import mmh3
import array
import math

class Bloom:
    def __init__(self, items, fp=0.01):
        m = -items * math.log(fp) / (math.log(2)**2)
        self.size = int(m)
        self.k = int(self.size / items * math.log(2))
        self.bits = array.array('B', [0]) * self.size

    def _hashes(self, item):
        for i in range(self.k):
            yield mmh3.hash(item, i) % self.size

    def add(self, item):
        for h in self._hashes(item):
            self.bits[h] = 1

    def __contains__(self, item):
        return all(self.bits[h] for h in self._hashes(item))
