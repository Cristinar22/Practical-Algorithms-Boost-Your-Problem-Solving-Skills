from datetime import datetime

def log_speed(before, after):
    gain = before / after
    print(f"[{datetime.now():%H:%M:%S}] Speed-up ×{gain:.1f}")
