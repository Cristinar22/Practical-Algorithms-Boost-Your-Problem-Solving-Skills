import heapq
heap = [3, 8, 5]
heapq.heapify(heap)
smallest = heapq.heappop(heap)
