import bisect
# Python keeps sorted arrays instead; concept identical.
