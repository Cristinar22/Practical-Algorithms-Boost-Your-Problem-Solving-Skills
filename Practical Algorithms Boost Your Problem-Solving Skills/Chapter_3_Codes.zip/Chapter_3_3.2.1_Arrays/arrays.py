nums = [10, 20, 30, 40]          # contiguous in memory
third = nums[2]                  # O(1)
