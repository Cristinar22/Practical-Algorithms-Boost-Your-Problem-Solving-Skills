class Node:
    def __init__(self, val, nxt=None):
        self.val, self.nxt = val, nxt
