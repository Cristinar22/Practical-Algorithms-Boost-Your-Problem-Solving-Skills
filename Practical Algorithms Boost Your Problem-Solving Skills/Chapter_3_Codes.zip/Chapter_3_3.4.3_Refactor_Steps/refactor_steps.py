contact_by_name = {c["name"]: c for c in contacts}

def add_contact(c):
    contact_by_name[c["name"]] = c

def get_contact(name):
    return contact_by_name.get(name)

def delete_contact(name):
    contact_by_name.pop(name, None)
