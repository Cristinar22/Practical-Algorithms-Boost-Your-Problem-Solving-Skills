import random, string, time, sys

def fake_name():
    return "".join(random.choice(string.ascii_lowercase) for _ in range(8))

contacts = [{"name": fake_name()} for _ in range(50_000)]
target = contacts[-1]["name"]

t0 = time.perf_counter()
get_contact(target)
print("O(n) list search:", time.perf_counter() - t0, "sec")
