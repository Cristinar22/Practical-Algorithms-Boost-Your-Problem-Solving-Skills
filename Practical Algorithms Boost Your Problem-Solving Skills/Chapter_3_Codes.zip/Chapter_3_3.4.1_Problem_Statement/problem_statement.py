contacts = [
    {"name": "Grace", "email": "..."},
    # 10 000 more
]

def get_contact(name):
    for c in contacts:
        if c["name"] == name:
            return c
