from collections import deque
q = deque()
q.append("passenger")
item = q.popleft()
