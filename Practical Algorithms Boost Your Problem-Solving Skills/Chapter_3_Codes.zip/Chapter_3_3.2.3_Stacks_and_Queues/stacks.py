stack = []
stack.append("plate")   # push
item = stack.pop()      # pop
