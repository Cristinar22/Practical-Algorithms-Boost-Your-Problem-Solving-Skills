def encode(node, bits):
    if node.val is not None:
        bits.append('1' if node.val else '2')
    else:
        bits.append('0')
        for ch in node.children:
            encode(ch, bits)

bits = []
encode(root, bits)
encoded = ''.join(bits).encode('ascii')
open('mri.qtree', 'wb').write(encoded)
