class Node:
    __slots__ = ('val', 'children')  # val = 0/1/None (mixed)
    def __init__(self, val=None):
        self.val = val
        self.children = None  # list of 4 Nodes
