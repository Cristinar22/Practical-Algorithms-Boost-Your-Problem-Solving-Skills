import timeit, random, math

base = random.randint(2, 10**6)
exp  = 10**8

print(timeit.timeit('power(base, exp)', globals=globals(), number=1))
print(timeit.timeit('pow(base, exp)',   globals=globals(), number=1))  # CPython C-optimised
