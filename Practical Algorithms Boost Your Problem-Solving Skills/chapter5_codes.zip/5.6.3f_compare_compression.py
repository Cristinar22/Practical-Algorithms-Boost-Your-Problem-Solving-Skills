import os

raw_size = os.path.getsize('mri_slice.png')
qt_size  = os.path.getsize('mri.qtree')

print(f"Raw PNG bytes: {raw_size:,}")
print(f"Quadtree bytes: {qt_size:,}  ({qt_size/raw_size:.1%} of original)")
