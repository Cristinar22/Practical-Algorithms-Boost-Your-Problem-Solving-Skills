from PIL import Image
import numpy as np

img = Image.open('mri_slice.png').convert('1')  # force monochrome
data = np.array(img, dtype=np.uint8)  # 0 or 1
