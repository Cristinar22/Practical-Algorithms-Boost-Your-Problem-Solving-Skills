def build(block):
    if block.size == 0:                     # safety
        return None
    if np.all(block == block[0,0]):         # uniform
        return Node(int(block[0,0]))
    n = Node()                              # mixed
    h, w = block.shape
    h2, w2 = h//2, w//2
    n.children = [
        build(block[:h2, :w2]),
        build(block[:h2, w2:]),
        build(block[h2:, :w2]),
        build(block[h2:, w2:]),
    ]
    return n
