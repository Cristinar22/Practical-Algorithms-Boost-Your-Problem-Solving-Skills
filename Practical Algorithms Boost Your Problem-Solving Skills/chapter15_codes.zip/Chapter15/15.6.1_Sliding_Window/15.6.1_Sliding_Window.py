def longest_substr_k_dist(s, k):
    counter = {}
    left = best = 0
    for right, ch in enumerate(s):
        counter[ch] = counter.get(ch,0) + 1
        while len(counter) > k:
            counter[s[left]] -= 1
            if counter[s[left]] == 0:
                del counter[s[left]]
            left += 1
        best = max(best, right - left + 1)
    return best
