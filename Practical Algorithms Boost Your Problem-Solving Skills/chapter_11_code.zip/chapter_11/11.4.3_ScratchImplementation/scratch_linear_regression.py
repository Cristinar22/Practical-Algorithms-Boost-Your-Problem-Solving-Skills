import numpy as np
import time

data = np.loadtxt("lagos_housing.csv", skiprows=1, delimiter=",")
X, y = data[:,0], data[:,1]
w, b, lr, epochs = 0.0, 0.0, 3e-9, 500

start = time.perf_counter()
loss_hist = []
for _ in range(epochs):
    y_hat = w*X + b
    diff = y_hat - y
    loss = (diff**2).mean()
    loss_hist.append(loss)
    w -= lr*(2*(diff*X)).mean()
    b -= lr*(2*diff).mean()
scratch_t = time.perf_counter() - start

print(f"Scratch implementation time: {scratch_t*1000:.2f} ms")
