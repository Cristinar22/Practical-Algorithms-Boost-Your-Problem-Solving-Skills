import numpy as np

def pca(X, k=2):
    Xc = X - X.mean(axis=0)
    cov = np.cov(Xc, rowvar=False)
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = eigvals.argsort()[::-1][:k]
    return Xc @ eigvecs[:, idx]
