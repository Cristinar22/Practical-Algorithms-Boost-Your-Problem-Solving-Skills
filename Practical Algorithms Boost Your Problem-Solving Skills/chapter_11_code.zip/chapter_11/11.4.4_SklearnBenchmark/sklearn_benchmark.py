import numpy as np
import time
from sklearn.linear_model import LinearRegression

# Load data
data = np.loadtxt("lagos_housing.csv", skiprows=1, delimiter=",")
X, y = data[:,0], data[:,1]

# Vanilla scikit-learn benchmark
model = LinearRegression()
start = time.perf_counter()
model.fit(X.reshape(-1,1), y)
sk_t = time.perf_counter() - start

r2 = model.score(X.reshape(-1,1), y)
print(f"Scikit-learn time: {sk_t*1000:.2f} ms, R² score: {r2:.3f}")
