import numpy as np
import pandas as pd

np.random.seed(42)
X = np.random.rand(10_000)*300  # 0–300 m²
noise = np.random.randn(10_000)*12_000
y = 150_000 + 350_000*X + noise
df = pd.DataFrame(dict(size=X, price=y))
df.to_csv("lagos_housing.csv", index=False)
