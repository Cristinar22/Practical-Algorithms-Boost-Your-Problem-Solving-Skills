def vanilla_gd(X, y, lr=0.01, epochs=500):
    w, b = 0.0, 0.0
    n = len(X)
    for _ in range(epochs):
        # predictions
        y_hat = w*X + b
        # gradients
        dw = (2/n)*((y_hat - y)*X).sum()
        db = (2/n)*(y_hat - y).sum()
        # update
        w -= lr*dw
        b -= lr*db
    return w, b
