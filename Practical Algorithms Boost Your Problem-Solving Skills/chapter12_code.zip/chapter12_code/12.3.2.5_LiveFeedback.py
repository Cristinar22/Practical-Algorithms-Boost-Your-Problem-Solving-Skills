from fastapi import FastAPI

app = FastAPI()

@app.get("/plan")
def plan():
    return current_routes   # updated each 5 min
