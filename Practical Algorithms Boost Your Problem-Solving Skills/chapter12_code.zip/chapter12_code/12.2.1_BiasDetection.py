import pandas as pd
df = pd.read_csv("loans.csv")
group_rates = (df.groupby("gender")
                 .apply(lambda g: (g.pred==1).mean()))
print(group_rates)   # flag if >5 % gap
