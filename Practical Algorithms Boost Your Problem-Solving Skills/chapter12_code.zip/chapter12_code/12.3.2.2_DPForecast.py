from functools import cache

@cache
def need(station, hour):
    if hour == 22:
        return 0
    baseline = hist_mean[station][hour]
    inflow   = rides_pred[station][hour]
    return max(0, baseline + inflow + need(station, hour+1))
