from collections import deque, defaultdict

windows = defaultdict(lambda: deque(maxlen=12))   # 12×5 min = 1 h

def ingest(station_id, bikes_left):
    dq = windows[station_id]
    dq.append(bikes_left)
    return sum(dq)/len(dq)   # current hourly mean
