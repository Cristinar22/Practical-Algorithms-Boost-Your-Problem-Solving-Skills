import math

def bellman(graph, src):
    dist={u:math.inf for u in graph}; dist[src]=0
    V=len(dist)
    for _ in range(V-1):
        changed=False
        for u in graph:
            for v,w in graph[u]:
                if dist[u]+w < dist[v]:
                    dist[v]=dist[u]+w; changed=True
        if not changed: break
    return dist
