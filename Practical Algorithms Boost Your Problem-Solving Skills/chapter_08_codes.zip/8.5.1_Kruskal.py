def kruskal(edges, n):
    parent=list(range(n))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]
            x=parent[x]
        return x
    mst, total = [], 0
    for w,u,v in sorted(edges):
        ru, rv = find(u), find(v)
        if ru!=rv:
            parent[ru]=rv
            mst.append((u,v,w)); total+=w
    return mst, total
