import heapq

def prim(graph, start=0):
    seen={start}; edges=[]; total=0
    heap=[(w, start, v) for v,w in graph[start]]
    heapq.heapify(heap)
    while heap:
        w,u,v = heapq.heappop(heap)
        if v in seen: continue
        seen.add(v); edges.append((u,v,w)); total+=w
        for x,wx in graph[v]:
            if x not in seen:
                heapq.heappush(heap,(wx, v, x))
    return edges, total
