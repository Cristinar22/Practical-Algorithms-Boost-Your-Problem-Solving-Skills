from collections import defaultdict
graph = defaultdict(list)
graph['A'].append(('B', 5))     # A --5--> B
