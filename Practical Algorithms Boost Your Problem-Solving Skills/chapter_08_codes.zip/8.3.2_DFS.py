def dfs(graph, start, seen=None):
    if seen is None: seen = set()
    seen.add(start)
    yield start
    for v, _ in graph[start]:
        if v not in seen:
            yield from dfs(graph, v, seen)
