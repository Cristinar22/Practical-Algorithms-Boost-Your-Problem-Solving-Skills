def topo_sort(graph):
    indeg = {u:0 for u in graph}
    for u in graph:
        for v,_ in graph[u]:
            indeg[v] = indeg.get(v,0)+1
    q = [u for u,d in indeg.items() if d==0]
    out=[]
    while q:
        u=q.pop()
        out.append(u)
        for v,_ in graph[u]:
            indeg[v]-=1
            if indeg[v]==0: q.append(v)
    if len(out)<len(indeg): raise ValueError("Cycle!")
    return out
