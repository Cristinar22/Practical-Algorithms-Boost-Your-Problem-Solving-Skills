import math

HQ = 'A'
worst_edge, worst_res = None, math.inf

for branch in graph:
    if branch == HQ: continue
    path = dijkstra_path(HQ, branch, graph)
    if not path: continue
    min_res = min(residual[e] for e in path)
    if min_res < worst_res:
        worst_res, worst_edge = min_res, path

print("Bottleneck residual", worst_res, "Mbps on path", worst_edge)
