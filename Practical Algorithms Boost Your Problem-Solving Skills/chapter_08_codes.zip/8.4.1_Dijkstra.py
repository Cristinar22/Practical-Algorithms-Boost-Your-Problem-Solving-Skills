import heapq
import math

def dijkstra(graph, src):
    dist = {u: math.inf for u in graph}
    dist[src]=0
    heap=[(0,src)]
    while heap:
        d,u = heapq.heappop(heap)
        if d!=dist[u]: continue
        for v,w in graph[u]:
            nd = d + w
            if nd < dist.get(v, math.inf):
                dist[v]=nd
                heapq.heappush(heap,(nd,v))
    return dist
