import heapq
import math

def dijkstra_path(src, dst, graph):
    dist={src:0}
    prev={}
    heap=[(0, src)]
    while heap:
        d,u = heapq.heappop(heap)
        if u==dst: break
        for v,w in graph[u]:
            nd = d + w
            if nd < dist.get(v, math.inf):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap,(nd, v))
    path = []
    if dst in dist:
        cur = dst
        while cur != src:
            par = prev[cur]
            path.append((par, cur))
            cur = par
        path.reverse()
    return path
