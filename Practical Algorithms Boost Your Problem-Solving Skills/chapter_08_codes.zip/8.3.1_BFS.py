from collections import deque

def bfs(graph, start):
    seen = {start}
    q = deque([start])
    while q:
        u = q.popleft()
        yield u
        for v, _ in graph[u]:
            if v not in seen:
                seen.add(v)
                q.append(v)
