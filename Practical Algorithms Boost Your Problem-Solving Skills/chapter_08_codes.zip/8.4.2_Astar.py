import heapq
import math

def astar(graph, src, goal, h):
    dist, est = {src:0}, {src:h(src)}
    pq=[(h(src), src)]
    prev={}
    while pq:
        f,u = heapq.heappop(pq)
        if u==goal: break
        for v,w in graph[u]:
            nd = dist[u]+w
            if nd < dist.get(v,math.inf):
                dist[v]=nd
                prev[v]=u
                heapq.heappush(pq,(nd+h(v), v))
    # reconstruct path
    path = []
    if goal in prev or goal == src:
        cur = goal
        while cur != src:
            path.append(cur)
            cur = prev[cur]
        path.append(src)
        path.reverse()
    return path
