import csv
import collections

graph = collections.defaultdict(list)
residual = {}

with open('lan_edges.csv') as f:
    for r in csv.DictReader(f):
        u, v = r['u'], r['v']
        lat  = float(r['lat_ms'])
        cap  = float(r['capacity_mbps'])
        load = float(r['load_mbps'])
        res  = cap - load
        graph[u].append((v, lat))
        graph[v].append((u, lat))
        residual[(u,v)] = res
        residual[(v,u)] = res
