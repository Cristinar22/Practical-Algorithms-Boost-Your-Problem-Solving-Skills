import re, collections
RX = re.compile(r"[A-Za-z']+")

def count_chunk(text: str) -> collections.Counter:
    return collections.Counter(w.lower() for w in RX.findall(text))
