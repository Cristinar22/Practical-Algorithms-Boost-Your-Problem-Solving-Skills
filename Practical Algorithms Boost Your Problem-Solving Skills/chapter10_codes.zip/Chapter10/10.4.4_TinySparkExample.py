from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
df = spark.read.text("hdfs:///logs/*.txt")
wc = (df.selectExpr("explode(split(value, '\\W')) AS word")
        .groupBy("word").count()
        .orderBy("count", ascending=False))
wc.show(10)
