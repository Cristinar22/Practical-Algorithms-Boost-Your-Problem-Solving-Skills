# Dask example for free cloud notebook (Colab/Kaggle)
# !pip install dask[complete]
import dask.bag as db

b = db.read_text('/content/books/*.txt').map(str.lower).str.split()
wc = b.flatten().frequencies().topk(10, key=1)
print(wc.compute())
