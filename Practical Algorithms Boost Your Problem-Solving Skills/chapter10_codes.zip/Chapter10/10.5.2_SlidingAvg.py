from collections import deque

def sliding_avg(stream, w=60):
    window, total = deque(), 0
    for x in stream:
        window.append(x)
        total += x
        if len(window) > w:
            total -= window.popleft()
        yield total / len(window)
