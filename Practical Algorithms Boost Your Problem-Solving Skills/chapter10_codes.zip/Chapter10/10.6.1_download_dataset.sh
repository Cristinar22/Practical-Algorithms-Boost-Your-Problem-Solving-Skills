#!/usr/bin/env bash
aria2c -c https://example.com/big_books.tar.gz
tar -xzf big_books.tar.gz
