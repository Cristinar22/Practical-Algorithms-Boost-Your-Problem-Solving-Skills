import time, sys
from pathlib import Path
from multiprocessing import Pool, cpu_count
import collections, re

RX = re.compile(r"[A-Za-z']+")

def count_chunk(text: str) -> collections.Counter:
    return collections.Counter(w.lower() for w in RX.findall(text))

def word_count(file: Path, chunk_size=4_000_000):
    blocks = []
    with file.open("r", encoding="utf-8") as f:
        while True:
            data = f.read(chunk_size)
            if not data:
                break
            blocks.append(data)
    with Pool(cpu_count()) as pool:
        partials = pool.map(count_chunk, blocks)
    return sum(partials, collections.Counter())

if __name__ == "__main__":
    log = Path(sys.argv[1])
    t0 = time.perf_counter()
    wc = word_count(log)
    print("Top 10:", wc.most_common(10))
    print("Elapsed:", time.perf_counter() - t0, "s")
