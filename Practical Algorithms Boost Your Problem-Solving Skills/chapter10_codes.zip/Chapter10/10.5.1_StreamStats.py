class StreamStats:
    def __init__(self):
        self.n = 0
        self.mean = 0
        self.M2 = 0

    def ingest(self, x):
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        self.M2 += delta * (x - self.mean)

    def variance(self):
        return self.M2 / (self.n - 1) if self.n > 1 else 0
