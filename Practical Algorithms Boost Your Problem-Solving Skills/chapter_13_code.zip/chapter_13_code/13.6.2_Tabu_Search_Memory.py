from collections import deque

tabu = deque(maxlen=7)

def move_operator(move):
    if move in tabu:
        return False
    tabu.append(move)
    return True
