import random, math

def anneal(seq, cost, T0=1_000, cool=0.995, steps=50_000):
    best = cur = seq[:]
    best_cost = cur_cost = cost(cur)
    T = T0
    for _ in range(steps):
        i, j = random.sample(range(len(seq)), 2)
        cand = cur[:]; cand[i], cand[j] = cand[j], cand[i]
        cand_cost = cost(cand)
        if cand_cost < cur_cost or random.random() < math.exp((cur_cost-cand_cost)/T):
            cur, cur_cost = cand, cand_cost
            if cand_cost < best_cost:
                best, best_cost = cand, cand_cost
        T *= cool
    return best, best_cost
