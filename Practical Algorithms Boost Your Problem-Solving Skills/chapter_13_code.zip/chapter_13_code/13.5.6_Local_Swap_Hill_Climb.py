def local_search(order, makespan):
    improved = True
    best = order[:]; best_cost = makespan(best)
    while improved:
        improved = False
        for i in range(len(best)-1):
            cand = best[:]; cand[i], cand[i+1] = cand[i+1], cand[i]
            c = makespan(cand)
            if c < best_cost:
                best, best_cost = cand, c
                improved = True
                break
    return best, best_cost
