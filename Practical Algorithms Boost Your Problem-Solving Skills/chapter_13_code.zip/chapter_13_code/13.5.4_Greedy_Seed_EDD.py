# Greedy seed: Earliest-Due-Date schedule
import pandas as pd

jobs = pd.read_csv("jobs.csv")
greedy = list(jobs.sort_values("due")["id"])
