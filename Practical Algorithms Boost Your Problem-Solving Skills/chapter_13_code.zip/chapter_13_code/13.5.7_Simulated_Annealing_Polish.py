# Assuming anneal and local_search are defined
seed, seed_cost = local_search(greedy, makespan)
final, final_cost = anneal(seed, makespan, T0=500, cool=0.998, steps=30_000)
