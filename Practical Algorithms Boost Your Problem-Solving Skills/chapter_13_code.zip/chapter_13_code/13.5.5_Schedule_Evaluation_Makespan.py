def makespan(order, jobs, m_machines=10):
    machine_times = [0] * m_machines
    for jid in order:
        m = min(range(m_machines), key=lambda i: machine_times[i])
        machine_times[m] += jobs.loc[jid, "proc"]
    return max(machine_times)
