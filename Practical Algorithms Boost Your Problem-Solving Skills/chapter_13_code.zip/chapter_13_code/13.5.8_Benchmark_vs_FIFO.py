import pandas as pd

fifo = list(jobs["id"])
results = pd.DataFrame({
    "Strategy": ["FIFO", "Greedy EDD", "Greedy+Local", "Hybrid (final)"],
    "Makespan": [makespan(fifo, jobs), makespan(greedy, jobs), seed_cost, final_cost]
})
print(results)
