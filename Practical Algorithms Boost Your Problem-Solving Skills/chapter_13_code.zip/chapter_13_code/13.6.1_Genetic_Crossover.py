import random

def crossover(p1, p2):
    cut = random.randint(1, len(p1) - 2)
    head = p1[:cut]
    tail = [j for j in p2 if j not in head]
    return head + tail
