def update_pheromone(trail, i, j, Q, length, evap=0.1):
    trail[i][j] = (1 - evap) * trail[i][j] + evap * (Q / length)
