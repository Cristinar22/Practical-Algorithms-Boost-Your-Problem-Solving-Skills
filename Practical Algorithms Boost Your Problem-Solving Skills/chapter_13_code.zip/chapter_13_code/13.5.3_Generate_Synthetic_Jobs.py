import numpy as np
import pandas as pd
np.random.seed(0)
n_jobs, m_machines = 120, 10
jobs = pd.DataFrame({
    "id": range(n_jobs),
    "proc": np.random.randint(20, 180, n_jobs),    # minutes
    "due":  np.random.randint(300, 1_200, n_jobs)  # minutes from shift start
})
jobs.to_csv("jobs.csv", index=False)
