import heapq
import collections

def rolling_median(stream, window=60):
    low, high = [], []  # max-heap, min-heap
    queue = collections.deque()

    for value in stream:
        queue.append(value)
        if not high or value >= high[0]:
            heapq.heappush(high, value)
        else:
            heapq.heappush(low, -value)

        # Rebalance
        if len(low) > len(high) + 1:
            heapq.heappush(high, -heapq.heappop(low))
        if len(high) > len(low) + 1:
            heapq.heappush(low, -heapq.heappop(high))

        # Drop old values
        if len(queue) > window:
            old = queue.popleft()
            if old in high:
                high.remove(old)
            else:
                low.remove(-old)
            heapq.heapify(high)
            heapq.heapify(low)

        # Compute median
        if len(high) > len(low):
            median = high[0]
        elif len(low) > len(high):
            median = -low[0]
        else:
            median = (high[0] - low[0]) / 2

        yield median