import numpy as np

def cg(A, b, tol=1e-10, maxit=1_000):
    x = np.zeros_like(b)
    r = b - A @ x
    p = r.copy()
    rs_old = r @ r
    for _ in range(maxit):
        Ap = A @ p
        alpha = rs_old / (p @ Ap)
        x += alpha * p
        r -= alpha * Ap
        rs_new = r @ r
        if rs_new**0.5 < tol:
            break
        p = r + (rs_new / rs_old) * p
        rs_old = rs_new
    return x
