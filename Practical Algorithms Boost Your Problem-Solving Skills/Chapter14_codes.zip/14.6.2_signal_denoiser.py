import numpy as np
import matplotlib.pyplot as plt

# Load ECG trace
ecg = np.loadtxt("ecg_noisy.csv")
fs = 360  # Hz
t = np.arange(len(ecg)) / fs

# Window & FFT
win = np.hanning(len(ecg))
fft_vals = np.fft.rfft(ecg * win)
freqs = np.fft.rfftfreq(len(ecg), 1/fs)

# Zero out frequencies > 40 Hz
cut = 40
fft_vals[freqs > cut] = 0
clean = np.fft.irfft(fft_vals) / win.mean()

# Plot before/after
plt.subplot(2, 1, 1)
plt.plot(t, ecg)
plt.title("Noisy")
plt.subplot(2, 1, 2)
plt.plot(t, clean)
plt.title("Denoised")
plt.show()

# Compute SNR
signal_power = np.var(clean)
noise_power  = np.var(ecg - clean)
snr_db = 10 * np.log10(signal_power / noise_power)
print("SNR dB:", snr_db)
