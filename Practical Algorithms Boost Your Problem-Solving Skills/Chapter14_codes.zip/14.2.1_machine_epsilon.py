import sys
import numpy as np

eps = np.finfo(float).eps
print("Machine epsilon:", eps)
