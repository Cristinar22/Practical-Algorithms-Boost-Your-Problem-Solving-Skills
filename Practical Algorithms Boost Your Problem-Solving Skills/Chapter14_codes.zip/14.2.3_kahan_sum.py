def kahan_sum(values):
    total = 0.0
    c = 0.0  # compensation
    for v in values:
        y = v - c
        t = total + y
        c = (t - total) - y
        total = t
    return total

# Try It Now
if __name__ == "__main__":
    import numpy as np, random
    vals = [random.random() for _ in range(1_000_000)]
    print(sum(vals) - kahan_sum(vals))  # ≈ 0 or tiny
