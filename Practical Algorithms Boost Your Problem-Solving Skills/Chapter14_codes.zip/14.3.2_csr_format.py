import numpy as np

class CSR:
    def __init__(self, rows, cols, data, indptr):
        self.rows = rows
        self.cols = cols
        self.data = data
        self.indptr = indptr

    @classmethod
    def from_dense(cls, A):
        data, indices, indptr = [], [], [0]
        for row in A:
            for j, val in enumerate(row):
                if val != 0:
                    data.append(val)
                    indices.append(j)
            indptr.append(len(data))
        return cls(A.shape[0], A.shape[1], np.array(data), np.array(indptr))
