a = 1_000_000.123456
b = 1_000_000.123455

print("Exact diff:", a - b)          # 1 × 10⁻⁶
print("After noisy ops:", (a + 1) - b)  # might be 0.0 on some hardware
