def newton(f, df, x0, tol=1e-10, n=20):
    x = x0
    for _ in range(n):
        x_new = x - f(x) / df(x)
        if abs(x_new - x) < tol:
            return x_new
        x = x_new
    return x
