from dataclasses import dataclass, field
import time

@dataclass(order=True)
class Entry:
    sort_index: tuple = field(init=False, repr=False)
    score: int
    ts: float = field(default_factory=time.time)
    player: str = field(compare=False)

    def __post_init__(self):
        # Negative score so highest score comes first in ascending tree
        self.sort_index = (-self.score, self.ts)
