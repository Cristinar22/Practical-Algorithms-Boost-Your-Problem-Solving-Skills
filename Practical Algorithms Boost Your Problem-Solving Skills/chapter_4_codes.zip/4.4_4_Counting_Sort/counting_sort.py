def counting_sort(nums, k):
    buckets = [0] * (k + 1)
    for v in nums:
        buckets[v] += 1
    out = []
    for val, count in enumerate(buckets):
        out.extend([val] * count)
    return out
