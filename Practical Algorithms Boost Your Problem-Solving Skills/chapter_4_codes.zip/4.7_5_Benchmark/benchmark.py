import random
import string
import time
import psutil
from leaderboard import LeaderBoard

def random_name():
    return "".join(random.choices(string.ascii_letters, k=8))

def run_benchmark(N=1_000_000):
    lb = LeaderBoard()
    start = time.perf_counter()

    for _ in range(N):
        lb.submit(random_name(), random.randint(0, 1_000_000))

    elapsed = time.perf_counter() - start
    mem = psutil.Process().memory_info().rss / 1024**2
    print(f"Inserts/s: {N/elapsed:,.0f}")
    print(f"RSS: {mem:.1f} MB")
    print("Top 5:", lb.top(5))

if __name__ == "__main__":
    run_benchmark()
