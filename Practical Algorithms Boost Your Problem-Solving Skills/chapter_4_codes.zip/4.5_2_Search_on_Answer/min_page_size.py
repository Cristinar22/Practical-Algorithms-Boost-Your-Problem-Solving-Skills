def min_page_size(books, shelves=10):
    lo, hi = max(books), sum(books)
    while lo < hi:
        mid = (lo + hi) // 2
        need, cur = 1, 0
        for pages in books:
            if cur + pages > mid:
                need += 1
                cur = 0
            cur += pages
        if need <= shelves:
            hi = mid
        else:
            lo = mid + 1
    return lo
