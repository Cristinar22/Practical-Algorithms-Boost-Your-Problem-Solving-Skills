def radix_sort(strings, width=10):
    for col in range(width - 1, -1, -1):
        buckets = [[] for _ in range(256)]
        for s in strings:
            buckets[ord(s[col])].append(s)
        strings = [s for bucket in buckets for s in bucket]
    return strings
