from sortedcontainers import SortedList
from entry import Entry

class LeaderBoard:
    def __init__(self):
        self.scores = SortedList()
        self.by_player = {}

    def submit(self, player, score):
        if player in self.by_player:
            old = self.by_player[player]
            if score <= old.score:
                return  # ignore non-improving
            self.scores.remove(old)
        entry = Entry(score=score, player=player)
        self.by_player[player] = entry
        self.scores.add(entry)

    def top(self, k=100):
        return [(e.player, e.score) for e in self.scores.islice(stop=k)]
