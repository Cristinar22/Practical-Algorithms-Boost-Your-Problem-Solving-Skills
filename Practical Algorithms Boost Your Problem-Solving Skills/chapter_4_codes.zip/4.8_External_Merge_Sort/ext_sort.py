import heapq
import os
import tempfile

def chunk_sort(input_file, chunk_size=100 * 1024 * 1024):
    temp_files = []
    with open(input_file, 'r') as f:
        while True:
            lines = f.readlines(chunk_size)
            if not lines:
                break
            lines.sort()
            tmp = tempfile.NamedTemporaryFile(delete=False, mode='w')
            tmp.writelines(lines)
            tmp.close()
            temp_files.append(tmp.name)
    return temp_files

def merge_files(temp_files, output_file):
    files = [open(tf, 'r') for tf in temp_files]
    heap = []
    for i, f in enumerate(files):
        line = f.readline()
        if line:
            heapq.heappush(heap, (line, i))
    with open(output_file, 'w') as out:
        while heap:
            line, idx = heapq.heappop(heap)
            out.write(line)
            next_line = files[idx].readline()
            if next_line:
                heapq.heappush(heap, (next_line, idx))
    for f in files:
        f.close()

if __name__ == "__main__":
    temp_files = chunk_sort('input.log')
    merge_files(temp_files, 'output.log')
