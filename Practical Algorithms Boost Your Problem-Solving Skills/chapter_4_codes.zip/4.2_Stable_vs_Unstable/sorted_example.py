rows = [
    ("Ada", 4200), ("Ben", 1400), ("Cyd", 4200)
]
print(sorted(rows, key=lambda r: r[1]))
# [('Ben', 1400), ('Ada', 4200), ('Cyd', 4200)]
