import heapq

def prim_mst(graph, start=0):
    visited, edges, total = {start}, [], 0
    for nxt, w in graph[start]:
        heapq.heappush(edges, (w, start, nxt))
    tree = []
    while edges and len(visited) < len(graph):
        w, u, v = heapq.heappop(edges)
        if v in visited:
            continue
        visited.add(v)
        tree.append((u, v, w))
        total += w
        for nxt, wt in graph[v]:
            if nxt not in visited:
                heapq.heappush(edges, (wt, v, nxt))
    return tree, total
