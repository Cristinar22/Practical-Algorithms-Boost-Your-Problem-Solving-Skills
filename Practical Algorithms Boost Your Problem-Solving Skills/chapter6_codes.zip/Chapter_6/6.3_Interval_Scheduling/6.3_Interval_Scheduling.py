def max_non_overlapping(talks):
    talks.sort(key=lambda x: x[1])   # sort by finish
    out, last_end = [], 0
    for s, f in talks:
        if s >= last_end:
            out.append((s, f))
            last_end = f
    return out
