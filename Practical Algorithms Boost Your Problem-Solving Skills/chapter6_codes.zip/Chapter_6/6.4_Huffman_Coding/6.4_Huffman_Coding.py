import heapq
import collections

def huffman_freqs(text):
    freq = collections.Counter(text)
    heap = [[wt, [sym, ""]] for sym, wt in freq.items()]
    heapq.heapify(heap)
    while len(heap) > 1:
        lo1, lo2 = heapq.heappop(heap), heapq.heappop(heap)
        for node in lo1[1:]:
            node[1] = "0" + node[1]
        for node in lo2[1:]:
            node[1] = "1" + node[1]
        heapq.heappush(heap, [lo1[0] + lo2[0]] + lo1[1:] + lo2[1:])
    return sorted(heapq.heapop(heap)[1:], key=lambda p: (len(p[1]), p))
