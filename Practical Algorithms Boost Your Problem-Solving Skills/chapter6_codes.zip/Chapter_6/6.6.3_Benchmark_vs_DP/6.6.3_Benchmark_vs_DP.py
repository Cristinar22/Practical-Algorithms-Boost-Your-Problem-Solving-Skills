import timeit
import random

targets = [random.randint(1, 999) for _ in range(1000)]
g = timeit.timeit('for t in targets: cashier(t)', globals=globals(), number=100)
print("Greedy time:", g)
