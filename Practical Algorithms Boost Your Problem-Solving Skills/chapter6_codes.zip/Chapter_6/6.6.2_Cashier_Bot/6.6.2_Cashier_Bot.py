def cashier(amount, coins=(100, 50, 20, 10, 5, 1)):
    out = []
    for coin in coins:
        while amount >= coin:
            amount -= coin
            out.append(coin)
    return out
